-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 27 Δεκ 2021 στις 10:03:26
-- Έκδοση διακομιστή: 10.4.22-MariaDB
-- Έκδοση PHP: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `ccc_version1`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `cm_transactions`
--

CREATE TABLE `cm_transactions` (
  `TRANSACTION_ID` varchar(15) NOT NULL,
  `CUSTOMER_ID` varchar(15) NOT NULL,
  `MERCHANT_ID` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `company`
--

CREATE TABLE `company` (
  `COMPANY_ID` varchar(15) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `LOGOTYPE` varchar(100) NOT NULL,
  `ESTABLISHMENT_DATE` year(4) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `AMOUNT_DUE` decimal(10,0) NOT NULL,
  `AMOUNT_DUE_DATE` date NOT NULL,
  `CREDIT_BALANCE` decimal(10,0) NOT NULL,
  `CREDIT_LIMIT` decimal(10,0) NOT NULL,
  `ACCOUNT_NUMBER` varchar(27) NOT NULL,
  `CUSTOMER_ID` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `company_phone`
--

CREATE TABLE `company_phone` (
  `COMPANY_ID` varchar(15) NOT NULL,
  `PHONE_NUMBER` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` varchar(15) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL,
  `LAST_NAME` varchar(100) NOT NULL,
  `BIRTH_DATE` date NOT NULL,
  `GENDER` char(1) NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `COMPANY_ID` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `employee_phone`
--

CREATE TABLE `employee_phone` (
  `EMPLOYEE_ID` varchar(15) NOT NULL,
  `PHONE_NUMBER` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `merchant`
--

CREATE TABLE `merchant` (
  `MERCHANT_ID` varchar(15) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL,
  `LAST_NAME` varchar(100) NOT NULL,
  `SUPPLY` decimal(10,0) NOT NULL,
  `GAIN` decimal(10,0) NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `AMOUNT_DUE` decimal(10,0) NOT NULL,
  `ACCOUNT_NUMBER` varchar(27) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `merchant_phone`
--

CREATE TABLE `merchant_phone` (
  `MERCHANT_ID` varchar(15) NOT NULL,
  `PHONE_NUMBER` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `private_citizen`
--

CREATE TABLE `private_citizen` (
  `AMKA` varchar(11) NOT NULL,
  `VAT` varchar(9) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL,
  `LAST_NAME` varchar(100) NOT NULL,
  `BIRTH_DATE` date NOT NULL,
  `GENDER` char(1) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `AMOUNT_DUE` decimal(10,0) NOT NULL,
  `ACCOUNT_DUE_DATE` date NOT NULL,
  `CREDIT_BALANCE` decimal(10,0) NOT NULL,
  `CREDIT_LIMIT` decimal(10,0) NOT NULL,
  `ACCOUNT_NUMBER` varchar(27) NOT NULL,
  `CUSTOMER_ID` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `private_citizen_phone`
--

CREATE TABLE `private_citizen_phone` (
  `AMKA` varchar(11) NOT NULL,
  `PHONE_NUMBER` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `product`
--

CREATE TABLE `product` (
  `PRODUCT_ID` varchar(15) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `PRICE` decimal(10,0) NOT NULL,
  `MERCHANT_ID` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `transaction`
--

CREATE TABLE `transaction` (
  `TRANSACTION_ID` varchar(15) NOT NULL,
  `TYPE` char(1) NOT NULL,
  `AMOUNT` decimal(10,0) NOT NULL,
  `DATE` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `cm_transactions`
--
ALTER TABLE `cm_transactions`
  ADD PRIMARY KEY (`TRANSACTION_ID`,`CUSTOMER_ID`,`MERCHANT_ID`);

--
-- Ευρετήρια για πίνακα `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`COMPANY_ID`,`ACCOUNT_NUMBER`,`CUSTOMER_ID`);

--
-- Ευρετήρια για πίνακα `company_phone`
--
ALTER TABLE `company_phone`
  ADD PRIMARY KEY (`COMPANY_ID`);

--
-- Ευρετήρια για πίνακα `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEE_ID`,`COMPANY_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Ευρετήρια για πίνακα `employee_phone`
--
ALTER TABLE `employee_phone`
  ADD PRIMARY KEY (`EMPLOYEE_ID`);

--
-- Ευρετήρια για πίνακα `merchant`
--
ALTER TABLE `merchant`
  ADD PRIMARY KEY (`MERCHANT_ID`,`ACCOUNT_NUMBER`);

--
-- Ευρετήρια για πίνακα `merchant_phone`
--
ALTER TABLE `merchant_phone`
  ADD PRIMARY KEY (`MERCHANT_ID`);

--
-- Ευρετήρια για πίνακα `private_citizen`
--
ALTER TABLE `private_citizen`
  ADD PRIMARY KEY (`AMKA`,`ACCOUNT_NUMBER`,`CUSTOMER_ID`);

--
-- Ευρετήρια για πίνακα `private_citizen_phone`
--
ALTER TABLE `private_citizen_phone`
  ADD PRIMARY KEY (`AMKA`);

--
-- Ευρετήρια για πίνακα `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`,`MERCHANT_ID`),
  ADD KEY `MERCHANT_ID` (`MERCHANT_ID`);

--
-- Ευρετήρια για πίνακα `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TRANSACTION_ID`);

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `company_phone`
--
ALTER TABLE `company_phone`
  ADD CONSTRAINT `company_phone_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Περιορισμοί για πίνακα `employee_phone`
--
ALTER TABLE `employee_phone`
  ADD CONSTRAINT `employee_phone_ibfk_1` FOREIGN KEY (`EMPLOYEE_ID`) REFERENCES `employee` (`EMPLOYEE_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `merchant_phone`
--
ALTER TABLE `merchant_phone`
  ADD CONSTRAINT `merchant_phone_ibfk_1` FOREIGN KEY (`MERCHANT_ID`) REFERENCES `merchant` (`MERCHANT_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `private_citizen_phone`
--
ALTER TABLE `private_citizen_phone`
  ADD CONSTRAINT `private_citizen_phone_ibfk_1` FOREIGN KEY (`AMKA`) REFERENCES `private_citizen` (`AMKA`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`MERCHANT_ID`) REFERENCES `merchant` (`MERCHANT_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
