-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 28 Δεκ 2021 στις 12:46:46
-- Έκδοση διακομιστή: 10.4.22-MariaDB
-- Έκδοση PHP: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `ccc_version1`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `cm_transactions`
--

CREATE TABLE `cm_transactions` (
  `CUSTOMER_ID` int(10) NOT NULL,
  `MERCHANT_ID` int(10) NOT NULL,
  `TRANSACTION` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `cm_transactions`
--

INSERT INTO `cm_transactions` (`CUSTOMER_ID`, `MERCHANT_ID`, `TRANSACTION`) VALUES
(1222, 3111, 5111),
(1555, 3222, 5222),
(1555, 3333, 5333),
(1444, 3555, 5333),
(1222, 3444, 5222);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `company`
--

CREATE TABLE `company` (
  `COMPANY_ID` int(10) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `LOGOTYPE` varchar(100) NOT NULL,
  `ESTABLISHMENT_DATE` date NOT NULL,
  `CUSTOMER_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `company`
--

INSERT INTO `company` (`COMPANY_ID`, `NAME`, `LOGOTYPE`, `ESTABLISHMENT_DATE`, `CUSTOMER_ID`) VALUES
(2111, 'Epignosis', 'EISIS', '2011-09-21', 1111),
(2222, 'Stonewave', 'EISIS', '2018-09-21', 1222),
(2333, 'Petas', 'EISIS', '2009-09-21', 1333),
(2444, 'Oikoses', 'EISIS', '2004-09-21', 1444),
(2555, 'Deloitte', 'EISIS', '2007-09-21', 1555);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `customer`
--

CREATE TABLE `customer` (
  `CUSTOMER_ID` int(10) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `AMOUNT_DUE` double NOT NULL,
  `ACCOUNT_DUE_DATE` date NOT NULL,
  `CREDIT_LIMIT` double NOT NULL,
  `CREDIT_BALANCE` double NOT NULL,
  `ACCOUNT_NUMBER` varchar(27) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `customer`
--

INSERT INTO `customer` (`CUSTOMER_ID`, `USERNAME`, `PASSWORD`, `EMAIL`, `ADDRESS`, `AMOUNT_DUE`, `ACCOUNT_DUE_DATE`, `CREDIT_LIMIT`, `CREDIT_BALANCE`, `ACCOUNT_NUMBER`) VALUES
(1111, 'Nazgul', 'wlcoding3440', 'savas@example.com', '(909) 982-4314 1534 Columbine Way Upland, California(CA), 91786', 0, '2011-11-07', 1000, 1000, 'GR11111111111122222222222XG'),
(1222, 'Mikkel', 'wlcoding3550', 'spirar@example.com', '(704) 938-1676 901 Oakwood Ave Kannapolis, North Carolina(NC), 28081', 10, '2014-03-31', 1000, 1000, 'GR33333333333344444444444XG'),
(1333, 'ZaFiR', 'wlcoding3660', 'epignosis@example.com', '(260) 768-7181 7280 W 350th N Shipshewana, Indiana(IN), 46565', 20, '2010-11-09', 1000, 1000, 'GR55555555555566666666666XG'),
(1444, 'Tsounis', 'wlcoding3770', 'stonewave@example.com', '(360) 757-0799 7727 Ershig Rd Bow, Washington(WA), 98232', 30, '2021-12-06', 1000, 1000, 'GR77777777777788888888888XG'),
(1555, 'RussheX', 'wlcoding3880', 'celina@example.com', '(513) 398-1549 776 Indianwood Dr Mason, Ohio(OH), 45040', 40, '2004-11-07', 1000, 1000, 'GR99999999999900000000000XG');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `customer_phone`
--

CREATE TABLE `customer_phone` (
  `CUSTOMER_ID` int(10) NOT NULL,
  `PHONE_NUMBER` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `customer_phone`
--

INSERT INTO `customer_phone` (`CUSTOMER_ID`, `PHONE_NUMBER`) VALUES
(1111, '6972221111'),
(1222, '6972222222'),
(1333, '6972223333'),
(1333, '6972227777'),
(1444, '6972224444'),
(1555, '6972225555');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_ID` int(10) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL,
  `LAST_NAME` varchar(100) NOT NULL,
  `BIRTH_DATE` date NOT NULL,
  `GENDER` char(1) NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `COMPANY_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `employee`
--

INSERT INTO `employee` (`EMPLOYEE_ID`, `FIRST_NAME`, `LAST_NAME`, `BIRTH_DATE`, `GENDER`, `ADDRESS`, `EMAIL`, `COMPANY_ID`) VALUES
(6111, 'Mahesh', 'Pegasus', '2011-11-30', 'M', '(804) 462-5266 98 Lakemont Rd Lancaster, Virginia(VA), 22503', 'mahesh@example.com', 2111),
(6222, 'Anna', 'Dervilla', '2001-11-30', 'F', '(804) 462-5266 98 Lakemont Rd Lancaster, Virginia(VA), 22503', 'anna@example.com', 2111),
(6333, 'Helena', 'Bart', '2006-11-30', 'F', '(319) 883-3563 429 W Donald St Waterloo, Iowa(IA), 50703', 'helena@example.com', 2222),
(6444, 'Pedro', 'Lema', '2004-11-30', 'M', '(661) 670-9845 24602 Town Center Dr Valencia, California(CA), 91355', 'pedro@example.com', 2333),
(6555, 'Vigga', 'Stegga', '2007-11-30', 'F', '(541) 459-4502 232 Riverwood Ln Oakland, Oregon(OR), 97462', 'vigga@example.com', 2555);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `employee_phone`
--

CREATE TABLE `employee_phone` (
  `EMPLOYEE_ID` int(10) NOT NULL,
  `PHONE_NUMBER` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `employee_phone`
--

INSERT INTO `employee_phone` (`EMPLOYEE_ID`, `PHONE_NUMBER`) VALUES
(6111, '6976660000'),
(6111, '6976661111'),
(6222, '6976662222'),
(6333, '6976663333'),
(6444, '6976664444'),
(6555, '6976665555');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `merchant`
--

CREATE TABLE `merchant` (
  `MERCHANT_ID` int(10) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL,
  `LAST_NAME` varchar(100) NOT NULL,
  `SUPPLY` double NOT NULL,
  `GAIN` double NOT NULL,
  `ADDRESS` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `AMOUNT_DUE` double NOT NULL,
  `ACCOUNT_NUMBER` varchar(27) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `merchant`
--

INSERT INTO `merchant` (`MERCHANT_ID`, `FIRST_NAME`, `LAST_NAME`, `SUPPLY`, `GAIN`, `ADDRESS`, `EMAIL`, `USERNAME`, `PASSWORD`, `AMOUNT_DUE`, `ACCOUNT_NUMBER`) VALUES
(3111, 'Jenny', 'Luitger', 0, 0, '(701) 594-8249 2733 New Jersey St #B Grand Forks Afb, North Dakota(ND), 58204', 'jenny@example.com', 'j3nn1', 'wlcoding3110', 0, 'GR11111111111122222222222CG'),
(3222, 'Tihana', 'Bret', 0, 0, '(701) 594-8249 2733 New Jersey St #B Grand Forks Afb, North Dakota(ND), 58204', 'tihana@example.com', 't1h4n4', 'wlcoding3220', 0, 'GR11111111111133333333333CG'),
(3333, 'Wilma', 'Lorenza', 0, 0, '757) 410-2495 717 Sea Pines Run Chesapeake, Virginia(VA), 23320', 'wilma@example.com', 'w1lm4', 'wlcoding3330', 0, 'GR11111111111144444444444CG'),
(3444, 'Roman', 'Erna', 0, 0, '(973) 838-0558 143 S Glen Rd Butler, New Jersey(NJ), 07405', 'roman@example.com', 'r0m4n', 'wlcoding3000', 0, 'GR11111111111155555555555CG'),
(3555, 'Ligia', 'Zara', 0, 0, '(561) 483-4884 2900 NW 32nd St Boca Raton, Florida(FL), 33434', 'ligia@example.com', 'l1g1a', 'wlcoding4110', 0, 'GR11111111111166666666666CG');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `merchant_phone`
--

CREATE TABLE `merchant_phone` (
  `MERCHANT_ID` int(10) NOT NULL,
  `PHONE_NUMBER` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `merchant_phone`
--

INSERT INTO `merchant_phone` (`MERCHANT_ID`, `PHONE_NUMBER`) VALUES
(3111, '6973331111'),
(3222, '6973332222'),
(3333, '6973333333'),
(3444, '6973334444'),
(3555, '6973335555'),
(3555, '6973337777');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `private_citizen`
--

CREATE TABLE `private_citizen` (
  `AMKA` varchar(11) NOT NULL,
  `VAT` varchar(9) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL,
  `LAST_NAME` varchar(100) NOT NULL,
  `BIRTH_DATE` date NOT NULL,
  `GENDER` char(1) NOT NULL,
  `CUSTOMER_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `private_citizen`
--

INSERT INTO `private_citizen` (`AMKA`, `VAT`, `FIRST_NAME`, `LAST_NAME`, `BIRTH_DATE`, `GENDER`, `CUSTOMER_ID`) VALUES
('11111111111', '122222222', 'Arthur', 'Zela', '2011-11-23', 'M', 1111),
('22222222222', '133333333', 'Melina', 'Zayne', '2009-11-23', 'F', 1222),
('33333333333', '155555555', 'Jacob', 'Miles', '2003-11-23', 'M', 1333),
('44444444444', '100000000', 'Ali', 'Coco', '2004-11-23', 'M', 1444),
('55555555555', '144444444', 'Selina', 'Feri', '2005-11-23', 'F', 1555);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `product`
--

CREATE TABLE `product` (
  `PRODUCT_ID` int(10) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `PRICE` double NOT NULL,
  `MERCHANT_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `NAME`, `PRICE`, `MERCHANT_ID`) VALUES
(4111, 'PC Games', 240.6, 3111),
(4222, 'PC Gadgets', 360.6, 3222),
(4333, 'PC Desktops ', 1240.6, 3333),
(4444, 'PC Laptops', 640.6, 3444),
(4555, 'PC Antivirus', 40.6, 3555),
(4666, 'Movies', 20.6, 3111);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `transaction`
--

CREATE TABLE `transaction` (
  `TRANSACTION_ID` int(10) NOT NULL,
  `TYPE` char(1) NOT NULL,
  `AMOUNT` double NOT NULL,
  `DATE` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `transaction`
--

INSERT INTO `transaction` (`TRANSACTION_ID`, `TYPE`, `AMOUNT`, `DATE`) VALUES
(5111, 'C', 103.7, '2013-10-08 05:59:36'),
(5222, 'C', 103.7, '2013-01-08 05:59:36'),
(5333, 'D', 3.7, '2010-12-08 05:59:36'),
(5444, 'C', 10.7, '2019-11-08 05:59:36'),
(5555, 'D', 153.7, '2020-01-08 05:59:36');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `cm_transactions`
--
ALTER TABLE `cm_transactions`
  ADD KEY `CUSTOMER_ID` (`CUSTOMER_ID`),
  ADD KEY `MERCHANT_ID` (`MERCHANT_ID`),
  ADD KEY `TRANSACTION` (`TRANSACTION`);

--
-- Ευρετήρια για πίνακα `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`COMPANY_ID`),
  ADD KEY `CUSTOMER_ID` (`CUSTOMER_ID`) USING BTREE;

--
-- Ευρετήρια για πίνακα `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CUSTOMER_ID`),
  ADD UNIQUE KEY `ACCOUNT_NUMBER` (`ACCOUNT_NUMBER`) USING BTREE;

--
-- Ευρετήρια για πίνακα `customer_phone`
--
ALTER TABLE `customer_phone`
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `CUSTOMER_ID` (`CUSTOMER_ID`);

--
-- Ευρετήρια για πίνακα `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEE_ID`),
  ADD KEY `COMPANY_ID` (`COMPANY_ID`);

--
-- Ευρετήρια για πίνακα `employee_phone`
--
ALTER TABLE `employee_phone`
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`);

--
-- Ευρετήρια για πίνακα `merchant`
--
ALTER TABLE `merchant`
  ADD PRIMARY KEY (`MERCHANT_ID`),
  ADD UNIQUE KEY `ACCOUNT_NUMBER` (`ACCOUNT_NUMBER`) USING BTREE;

--
-- Ευρετήρια για πίνακα `merchant_phone`
--
ALTER TABLE `merchant_phone`
  ADD UNIQUE KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `MERCHANT_ID` (`MERCHANT_ID`);

--
-- Ευρετήρια για πίνακα `private_citizen`
--
ALTER TABLE `private_citizen`
  ADD PRIMARY KEY (`AMKA`),
  ADD UNIQUE KEY `CUSTOMER_ID` (`CUSTOMER_ID`) USING BTREE;

--
-- Ευρετήρια για πίνακα `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`),
  ADD KEY `MERCHANT_ID` (`MERCHANT_ID`);

--
-- Ευρετήρια για πίνακα `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TRANSACTION_ID`);

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `cm_transactions`
--
ALTER TABLE `cm_transactions`
  ADD CONSTRAINT `cm_transactions_ibfk_1` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customer` (`CUSTOMER_ID`),
  ADD CONSTRAINT `cm_transactions_ibfk_2` FOREIGN KEY (`MERCHANT_ID`) REFERENCES `merchant` (`MERCHANT_ID`),
  ADD CONSTRAINT `cm_transactions_ibfk_3` FOREIGN KEY (`TRANSACTION`) REFERENCES `transaction` (`TRANSACTION_ID`);

--
-- Περιορισμοί για πίνακα `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `company_ibfk_1` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customer` (`CUSTOMER_ID`);

--
-- Περιορισμοί για πίνακα `customer_phone`
--
ALTER TABLE `customer_phone`
  ADD CONSTRAINT `customer_phone_ibfk_1` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customer` (`CUSTOMER_ID`);

--
-- Περιορισμοί για πίνακα `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `employee_phone`
--
ALTER TABLE `employee_phone`
  ADD CONSTRAINT `employee_phone_ibfk_1` FOREIGN KEY (`EMPLOYEE_ID`) REFERENCES `employee` (`EMPLOYEE_ID`);

--
-- Περιορισμοί για πίνακα `merchant_phone`
--
ALTER TABLE `merchant_phone`
  ADD CONSTRAINT `merchant_phone_ibfk_1` FOREIGN KEY (`MERCHANT_ID`) REFERENCES `merchant` (`MERCHANT_ID`);

--
-- Περιορισμοί για πίνακα `private_citizen`
--
ALTER TABLE `private_citizen`
  ADD CONSTRAINT `private_citizen_ibfk_1` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customer` (`CUSTOMER_ID`);

--
-- Περιορισμοί για πίνακα `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`MERCHANT_ID`) REFERENCES `merchant` (`MERCHANT_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
